#include "Candidate.h"
#include <iostream>

// Constructor
Candidate::Candidate(const std::string &id, const std::string &username,
                     const std::string &password, const std::string &resume,
                     const std::string &fname, const std::string &lname,
                     const std::string &email, const std::string &phone,
                     const std::string &address, const std::string &linkedIn,
                     const std::string &skills, const std::string &experience)
    : User(username, password), candidate_id(id), resume(resume),
      first_Name(fname), last_Name(lname), email(email), phone(phone),
      address(address), linkedIn(linkedIn), skills(skills),
      experience(experience) {}

void Candidate::display() {
  std::cout << "Candidate ID: " << candidate_id << "\n"
            << "Resume: " << resume << "\n"
            << "First Name: " << first_Name << "\n"
            << "Last Name: " << last_Name << "\n"
            << "Email: " << email << "\n"
            << "Phone: " << phone << "\n"
            << "Address: " << address << "\n"
            << "LinkedIn: " << linkedIn << "\n"
            << "Skills: " << skills << "\n"
            << "Experience: " << experience << "\n";
}

void Candidate::searchJob() {}

void Candidate::submitApplication() {}

void Candidate::scheduledInterview() {}

void Candidate::receiveJobOfferInfo() {}

void Candidate::addFeedback() {}
