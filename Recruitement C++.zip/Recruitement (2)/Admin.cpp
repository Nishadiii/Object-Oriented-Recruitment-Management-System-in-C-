#include "Admin.h"
#include <iostream>

Admin::Admin(const std::string &username, const std::string &password,
             const std::string &adminID, const std::string &fname,
             const std::string &lname, const std::string &email,
             const std::string &phone, const std::string &address)
    : User(username, password), admin_id(adminID), first_Name(fname),
      last_Name(lname), email(email), phone(phone), address(address) {}

void Admin::approveVacancies() {}

void Admin::manageJobPosts() {}

void Admin::scheduleInterview() {}

void Admin::generateReport() {}

void Admin::manageApplication() {}

void Admin::manageFeedback() {}

void Admin::display() {
  std::cout << "Admin ID: " << admin_id << "\n"
            << "First Name: " << first_Name << "\n"
            << "Last Name: " << last_Name << "\n"
            << "Email: " << email << "\n"
            << "Phone: " << phone << "\n"
            << "Address: " << address << "\n";
}
