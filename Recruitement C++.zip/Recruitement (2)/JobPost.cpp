#include "JobPost.h"
#include <iostream>

JobPost::JobPost(const std::string &jobID, const std::string &clientID,
                 const std::string &jobTitle, const std::string &jobDesc,
                 const std::string &req, const std::string &loc,
                 const std::string &sal, bool status)
    : job_ID(jobID), client_ID(clientID), job_title(jobTitle),
      job_description(jobDesc), requirements(req), location(loc), salary(sal),
      status(status) {}

void JobPost::storeJobDetails() {}

void JobPost::notifyAdminApproval() {}

void JobPost::displayApprovedJob() {}

bool JobPost::getStatus() const { return status; }

void JobPost::setStatus(bool newStatus) { status = newStatus; }

void JobPost::display() {
  std::cout << "Job ID: " << job_ID << "\n"
            << "Client ID: " << client_ID << "\n"
            << "Job Title: " << job_title << "\n"
            << "Job Description: " << job_description
            << "\n"
               "Requirements: "
            << requirements
            << "\n"
               "Location: "
            << location << "\n"
            << "Salary: " << salary << "\n"
            << "Status: " << (status ? "Approved" : "Pending") << "\n";
}