#pragma once
#include <string>

class Report {
private:
  std::string application_ID;
  std::string job_ID;
  std::string candidate_ID;

public:
  Report(const std::string &appID, const std::string &jobID,
         const std::string &candID);
  void storeApplicationDetails();
  void sendApplicationClient();
  void applicationStatus();
  void display();
};
