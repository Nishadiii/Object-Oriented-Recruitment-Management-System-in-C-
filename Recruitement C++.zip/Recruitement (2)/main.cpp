#include "Admin.h"
#include "Application.h"
#include "Candidate.h"
#include "ClientCompany.h"
#include "Feedback.h"
#include "Interview.h"
#include "JobOffer.h"
#include "JobPost.h"
#include "iostream"

int main() {
  // Create an Admin
  Admin admin("admin001", "adminpass001", "A123", "Senumi", "Damsiluni",
              "SenumiDamsiluni@gmail.com", "0712233945",
              "Admin Sliit,Kaduwela Rd, Malabe");

  // Create a Candidate
  Candidate candidate("C001", "Amara", "Amara123", "AmaraCV.pdf", "Amara",
                      "Senavirathne", "AmaraSena@gmail.com", "0784838222",
                      "3rd Lane,Gamunupura rd,Malabe, Kothalawala",
                      "linkedin.com/Amara", "Programming, Communication",
                      "1 year");

  // Create a ClientCompany
  ClientCompany company("virtusaSL", "VirtusaSL123", "Cl001", "Virtusa Pvt.LTD",
                        "IT Services", "VirtusaSLCMB@virtusa.com",
                        "0112238384");

  // Create an Application
  Application application("APP001", "JOB001", "C001");

  // Create Feedback
  Feedback feedback("F001", "Amara", "5 stars", "Excellent service!");

  // Create an Interview
  Interview interview("INT001", "C001", "JOB001", "2024-05-20", "10:00 AM");

  // Create a JobOffer
  JobOffer jobOffer("JOB001", "C001", "C001", "Offer details here");

  JobPost jobPost(
      "JOB001", "Cl001", "Software Developer",
      "Manual Debugging Drudgery: Forget the old ways of debugging. You're "
      "equipped with AI to spot and solve issues effortlessly.",
      "Skills required...Programming/Communication", "OrianCity Colombo 08",
      "$80,000 - $100,000", true);

  // Display Admin details
  std::cout << "Admin Details:" << std::endl;
  admin.display();
  std::cout << std::endl;

  // Display Candidate details
  std::cout << "Candidate Details:" << std::endl;
  candidate.display();
  std::cout << std::endl;
  // Display ClientCompany details
  std::cout << "Client Company Details:" << std::endl;
  company.display();
  std::cout << std::endl;
  // Display Application details
  std::cout << "Application Details:" << std::endl;
  application.display();
  std::cout << std::endl;
  // Show Feedback details
  std::cout << "Feedback Details:" << std::endl;
  feedback.showFeedback();
  std::cout << std::endl;
  // Display Interview details
  std::cout << "Interview Details:" << std::endl;
  interview.display();
  std::cout << std::endl;
  // Display Job Offer details
  std::cout << "Job Offer Details:" << std::endl;
  jobOffer.display();
  std::cout << std::endl;
  // Display JobPost details
  std::cout << "Job Post Details:" << std::endl;
  jobPost.display();
  std::cout << std::endl;

  return 0;
}
