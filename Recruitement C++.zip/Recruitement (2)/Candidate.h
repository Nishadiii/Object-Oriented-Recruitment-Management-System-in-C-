#pragma once
#include "User.h"
#include <string>

class Candidate : public User {
private:
  std::string candidate_id;
  std::string resume;
  std::string first_Name;
  std::string last_Name;
  std::string email;
  std::string phone;
  std::string address;
  std::string linkedIn;
  std::string skills;
  std::string experience;

public:
  Candidate(const std::string &id, const std::string &username,
            const std::string &password, const std::string &resume,
            const std::string &fname, const std::string &lname,
            const std::string &email, const std::string &phone,
            const std::string &address, const std::string &linkedIn,
            const std::string &skills, const std::string &experience);
  void searchJob();
  void submitApplication();
  void scheduledInterview();
  void receiveJobOfferInfo();
  void addFeedback();
  void display();
};
