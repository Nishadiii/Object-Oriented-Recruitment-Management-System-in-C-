#pragma once
#include "User.h"
#include <string>

class Admin : public User {
private:
  std::string admin_id;
  std::string first_Name;
  std::string last_Name;
  std::string email;
  std::string phone;
  std::string address;

public:
  Admin(const std::string &username, const std::string &password,
        const std::string &adminID, const std::string &fname,
        const std::string &lname, const std::string &email,
        const std::string &phone, const std::string &address);
  void approveVacancies();
  void manageJobPosts();
  void scheduleInterview();
  void generateReport();
  void manageApplication();
  void manageFeedback();
  void display();
};
