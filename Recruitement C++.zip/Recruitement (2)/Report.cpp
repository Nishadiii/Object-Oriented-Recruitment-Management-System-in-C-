#include "Report.h"
#include <iostream>

Report::Report(const std::string &appID, const std::string &jobID,
               const std::string &candID)
    : application_ID(appID), job_ID(jobID), candidate_ID(candID) {}

void Report::storeApplicationDetails() {}

void Report::sendApplicationClient() {}

void Report::applicationStatus() {}
void Report::display() {
  std::cout << "Application ID: " << application_ID << "\n"
            << "Job ID: " << job_ID << "\n"
            << "Candidate ID: " << candidate_ID << "\n";
}