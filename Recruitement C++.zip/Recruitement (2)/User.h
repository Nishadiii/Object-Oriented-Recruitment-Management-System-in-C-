#pragma once
#include <string>

class User {
private:
  std::string username;
  std::string password;

public:
  User(const std::string &username, const std::string &password);
  void registerSystem();
  void login();
  void validateUser();
  void display();
};