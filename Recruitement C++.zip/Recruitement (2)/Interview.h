#pragma once
#include <string>

class Interview {
private:
  std::string interview_id;
  std::string candidate_id;
  std::string job_ID;
  std::string interview_date;
  std::string interview_time;

public:
  Interview(const std::string &interviewID, const std::string &candID,
            const std::string &jobID, const std::string &date,
            const std::string &time);
  void scheduleInterview();
  void notifyCandidate();
  void notifyClientCompany();
  void display();
};
