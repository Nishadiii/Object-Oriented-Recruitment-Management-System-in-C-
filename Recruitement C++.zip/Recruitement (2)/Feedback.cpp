#include "Feedback.h"
#include <iostream>

Feedback::Feedback(const std::string &feedbackID, const std::string &username,
                   const std::string &rating, const std::string &desc)
    : feedback_id(feedbackID), username(username), rating(rating),
      description(desc) {}

void Feedback::showFeedback() {
  std::cout << "Feedback ID: " << feedback_id << "\n"
            << "Username: " << username << "\n"
            << "Rating: " << rating << "\n"
            << "Description: " << description << "\n";
}
