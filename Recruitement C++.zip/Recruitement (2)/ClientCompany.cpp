#include "ClientCompany.h"
#include <iostream>

ClientCompany::ClientCompany(const std::string &username,
                             const std::string &password,
                             const std::string &clientID,
                             const std::string &compName,
                             const std::string &industry,
                             const std::string &email,
                             const std::string &contact)
    : User(username, password), client_id(clientID), company_name(compName),
      industry(industry), email(email), contact_no(contact) {}

void ClientCompany::sendVacancies() {}

void ClientCompany::sendInterviewDetails() {}

void ClientCompany::checkApplication() {}

void ClientCompany::sendFeedback() {}

void ClientCompany::recieveApprovedInterviewDetails() {}

void ClientCompany::display() {
  std::cout << "Client ID: " << client_id << "\n"
            << "Company Name: " << company_name << "\n"
            << "Industry: " << industry << "\n"
            << "Email: " << email << "\n"
            << "Contact Number: " << contact_no << "\n";
}
