#include "User.h"

User::User(const std::string &username, const std::string &password)
    : username(username), password(password) {}

void User::registerSystem() {}

void User::login() {}

void User::validateUser() {}

void User::display() {}