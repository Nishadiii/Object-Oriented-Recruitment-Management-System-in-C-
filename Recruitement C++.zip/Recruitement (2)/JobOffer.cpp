#include "JobOffer.h"
#include <iostream>

JobOffer::JobOffer(const std::string &offerID, const std::string &clientID,
                   const std::string &candID, const std::string &details)
    : jobOffer_id(offerID), client_id(clientID), candidate_id(candID),
      offerDetails(details) {}

void JobOffer::createOffer() {}

void JobOffer::notifyCandidate() {}

void JobOffer::acceptOffer() {}

void JobOffer::rejectOffer() {}
void JobOffer::display() {
  std::cout << "Job Offer ID: " << jobOffer_id << "\n"
            << "Client ID: " << client_id << "\n"
            << "Candidate ID: " << candidate_id << "\n"
            << "Offer Details: " << offerDetails << "\n";
}