#pragma once
#include <string>

class Feedback {
private:
  std::string feedback_id;
  std::string username;
  std::string rating;
  std::string description;

public:
  Feedback(const std::string &feedbackID, const std::string &username,
           const std::string &rating, const std::string &desc);
  void showFeedback();
  void display();
};
