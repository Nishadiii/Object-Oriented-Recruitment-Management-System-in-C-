#pragma once
#include <string>

class JobPost {
private:
  std::string job_ID;
  std::string client_ID;
  std::string job_title;
  std::string job_description;
  std::string requirements;
  std::string location;
  std::string salary;
  bool status;

public:
  JobPost(const std::string &jobID, const std::string &clientID,
          const std::string &jobTitle, const std::string &jobDesc,
          const std::string &req, const std::string &loc,
          const std::string &sal, bool status);
  void storeJobDetails();
  void notifyAdminApproval();
  void displayApprovedJob();
  bool getStatus() const;
  void setStatus(bool newStatus);
  void display();
};
