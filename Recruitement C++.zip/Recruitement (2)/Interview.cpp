#include "Interview.h"
#include <iostream>

Interview::Interview(const std::string &interviewID, const std::string &candID,
                     const std::string &jobID, const std::string &date,
                     const std::string &time)
    : interview_id(interviewID), candidate_id(candID), job_ID(jobID),
      interview_date(date), interview_time(time) {}

void Interview::scheduleInterview() {}

void Interview::notifyCandidate() {}

void Interview::notifyClientCompany() {}
void Interview::display() {
  std::cout << "Interview ID: " << interview_id << "\n"
            << "Candidate ID: " << candidate_id << "\n"
            << "Job ID: " << job_ID << "\n"
            << "Interview Date: " << interview_date << "\n"
            << "Interview Time: " << interview_time << "\n";
}