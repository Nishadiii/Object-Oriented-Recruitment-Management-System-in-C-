#include "Application.h"
#include <iostream>
Application::Application(const std::string &appID, const std::string &jobID,
                         const std::string &candID)
    : application_ID(appID), job_ID(jobID), candidate_ID(candID) {}

void Application::storeApplicationDetails() {}

void Application::sendApplicationClient() {}

void Application::applicationStatus() {}

void Application::display() {
  std::cout << "Application ID: " << application_ID << "\n"
            << "Job ID: " << job_ID << "\n"
            << "Candidate ID: " << candidate_ID << "\n";
}
