#pragma once
#include <string>

class JobOffer {
private:
  std::string jobOffer_id;
  std::string client_id;
  std::string candidate_id;
  std::string offerDetails;

public:
  JobOffer(const std::string &offerID, const std::string &clientID,
           const std::string &candID, const std::string &details);
  void createOffer();
  void notifyCandidate();
  void acceptOffer();
  void rejectOffer();
  void display();
};
