#pragma once
#include "User.h"
#include <string>

class ClientCompany : public User {
private:
  std::string client_id;
  std::string company_name;
  std::string industry;
  std::string email;
  std::string contact_no;

public:
  ClientCompany(const std::string &username, const std::string &password,
                const std::string &clientID, const std::string &compName,
                const std::string &industry, const std::string &email,
                const std::string &contact);
  void sendVacancies();
  void sendInterviewDetails();
  void checkApplication();
  void display();
  void recieveApprovedInterviewDetails();
  void sendFeedback();
};
